****Instructions****
To start open tetris.html
You may want to CHANGE USER to a username that you prefer

The controls are UP, DOWN, LEFT, RIGHT
LEFT and RIGHT move the block left and right
UP rotates the block clockwise by 90 degrees
DOWN moves the block down by 1 square

Holding DOWN may be dangerous

BEGIN GAME begins the game
<- and -> change the current game mode
You can only change the current game mode after clicking NEW GAME
CHANGE USER or clicking away from the box changes the current user
Changing the user changes the name in HIGHSCORES

HIGHSCORES can only be obtained upon sufficient score
Getting more LINES at once gets more SCORE than getting each line individually
**   HIGHSCORES are saved locally and can be deleted   **
**  by clearing browser cookies, cached, history, etc  **
(or whatever. I only pretend I know how things work)

And remember, have fun!